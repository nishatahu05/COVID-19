import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class h5 {
    private JTextArea a1HealthCallCentreTextArea;
    public JPanel j5;
    private JButton preButton;

    public h5() {//pre
        preButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                COVID19.frame.setContentPane(new  jh4().j4);
                COVID19.frame.show();
            }
        });
    }
}
