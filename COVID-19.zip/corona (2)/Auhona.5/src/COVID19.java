//swing
import javax.swing.*;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class COVID19 {

    private JTextField t1;//name
    private JTextField t4;//phone
    private JRadioButton maleRadioButton;
    private JRadioButton femaleRadioButton;
    private JTextField t2;//gender
    private JTextField t3;//age
    private JButton b1;
    private JButton b2;
    public JPanel j1;//cccc
     public static JFrame frame;//global jfram

    public static void main(String[] args) {//main
        frame = new JFrame("Auhona");
        frame.setContentPane(new COVID19().j1);//j1
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public COVID19() { //save
        // Save button
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //sms show save button.
            JOptionPane.showMessageDialog(null,"Enter Successfully","",JOptionPane.PLAIN_MESSAGE);
            }
        });
        // End

        // next button
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                frame.setContentPane(new frm2().j2);
                frame.show();
            }
        });
        // Enter button end

    }
}


