import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class jh4 {
    private JButton next;
    public JPanel j4;
    private JTextArea washYourHandsFrequentlyTextArea;
    private JTextArea coverMouthAndNoseTextArea;
    private JTextArea avoidCloseContactWithTextArea;
    private JTextArea seekMedicalCareEarlyTextArea;
    private JButton preButton;
    public static JFrame frame;
    public jh4() {
        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        //pre
        preButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                COVID19.frame.setContentPane(new  frm3().j3);
                COVID19.frame.show();
            }
        });//next
        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                COVID19.frame.setContentPane(new  h5().j5);
                COVID19.frame.show();
            }
        });
    }
}
