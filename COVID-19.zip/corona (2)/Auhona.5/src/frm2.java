import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class frm2 {
    private JButton button1;
    public JPanel j2;
    private JButton back;
    private JLabel l1;
    private JTextArea coronavirusesAreAGroupTextArea;
    private JTextArea httpsWwwGoogleComTextArea;
    // public static JFrame frame;
    /*public static void main(String[] args) {
        frame = new JFrame("ll");
        frame.setContentPane(new frm2().j2);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }*/

    public frm2() {
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                COVID19.frame.setContentPane(new  frm3().j3);
                COVID19.frame.show();
            }
        });
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                COVID19.frame.setContentPane(new  COVID19().j1);
                COVID19.frame.show();
            }
        });
    }
}
