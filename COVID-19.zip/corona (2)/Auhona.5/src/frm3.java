import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class frm3 {
    private JButton Next;
    public JPanel j3;
    private JTextArea a1Fever2DryTextArea;
    private JTextArea a1AchesAndPainsTextArea;
    private JTextArea a1DifficultyBreathingOrTextArea;
    private JButton prevButton;
    public static JFrame frame;



    public frm3() {
        //next
        Next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                COVID19.frame.setContentPane(new  jh4().j4);
                COVID19.frame.show();
            }
        });
        //pre
        prevButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                COVID19.frame.setContentPane(new  frm2().j2);
                COVID19.frame.show();
            }
        });
    }
}
